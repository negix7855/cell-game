# =========================
# ランキング（Supabase）の接続先
# =========================
#
# Supabase の管理画面で確認した値を書き込む
#   SUPABASE_URL : Project URL（https://xxxx.supabase.co）
#   SUPABASE_KEY : 公開用のキー（publishable key「sb_publishable_...」または anon key）
#
# ゲームに埋め込まれて公開される前提のキーなので、ここに書いて問題ない。
# ただし secret key / service_role key は絶対に書かないこと。

SUPABASE_URL = "https://lrjqedywaxmwrmuzrcyv.supabase.co"
SUPABASE_KEY = "sb_publishable_Dy_PH5EH8QAOuYUeO8OzbQ_5hL8_4qt"
